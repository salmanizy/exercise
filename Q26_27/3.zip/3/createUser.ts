import User from './user';

export function createUser(user: User): void {
    console.log(user);
}