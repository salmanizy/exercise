"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFriend = createFriend;
function createFriend(user) {
    console.log({
        name: user.name
    });
}
