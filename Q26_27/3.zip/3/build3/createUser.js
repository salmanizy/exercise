"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUser = createUser;
function createUser(user) {
    console.log(user);
}
