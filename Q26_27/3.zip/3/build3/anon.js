"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAnon = createAnon;
function createAnon(user) {
    console.log({
        gender: user.gender,
        address: user.address
    });
}
