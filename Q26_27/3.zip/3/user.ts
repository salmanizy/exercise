export default interface User {
    name: string;
    address?: string;
    gender: "Laki-laki" | "Perempuan";
}